<div class="bannerMain">
    <div class="container-fluid">
        <div class="d-flex">
            <div class="textBox">
                <p>March 12,  2024</p>
                <h2>Welcome, Sela!</h2>
                <p>Always stay updated in your student portal</p>
                <div class="btnDiv d-flex">
                    <button class="btn">Take Your  Quiz</button>
                    <button class="btn">Pick Your Plan</button>
                </div>
            </div>
            <div class="imgBox">
                <img src="{{ asset('assets/img/student.png') }}" alt="">
            </div>
        </div>
    </div>
</div>