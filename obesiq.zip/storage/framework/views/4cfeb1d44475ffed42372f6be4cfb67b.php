
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="progressDiv">
        <div class="container-fluid">
            <div class="headingSec">
                <h2>Progress Report</h2>
            </div>
            <div class="progressBox">
                <div class="row">
                    <div class="col-lg-4">
                        <canvas class="myDonutChart"></canvas>
                    </div>
                    <div class="col-lg-4">
                        <h3>Your Score</h3>
                        <div class="scores">
                            <div class="d-flex">
                                <p>Total Correct</p>
                                <div class="count">
                                    <p>7</p>
                                </div>
                            </div>
                            <div class="d-flex">
                                <p>Total Incorrect</p>
                                <div class="count">
                                    <p>7</p>
                                </div>
                            </div>
                            <div class="d-flex">
                                <p>Total Omitted </p>
                                <div class="count">
                                    <p>7</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <h3>Your Score</h3>
                        <div class="scores">
                            <div class="d-flex">
                                <p>Total Correct</p>
                                <div class="count">
                                    <p>7</p>
                                </div>
                            </div>
                            <div class="d-flex">
                                <p>Total Incorrect</p>
                                <div class="count">
                                    <p>7</p>
                                </div>
                            </div>
                            <div class="d-flex">
                                <p>Total Omitted </p>
                                <div class="count">
                                    <p>7</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\obesiq\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>