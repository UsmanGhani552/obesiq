
<?php $__env->startSection('content'); ?>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
    }

    .result-container {
        border: 1px solid #ccc;
        padding: 15px;
        margin-bottom: 20px;
    }

    .question {
        font-weight: bold;
        margin-bottom: 10px;
    }

    .options {
        margin-bottom: 10px;
    }

    .option {
        padding: 5px;
        border: 1px solid #ccc;
        margin: 2px 0;
        border-radius: 4px;
        display: block;
    }

    .correct {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .selected {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    .explanation {
        font-style: italic;
        color: #6c757d;
    }

</style>

<h1>Quiz Results</h1>
<div id="results-container"></div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Retrieve results from session storage
        const results = JSON.parse(sessionStorage.getItem('quizResults'));

        if (results) {
            const container = document.getElementById('results-container');
            results.forEach(result => {
                console.log(result.selected_answer.split(",")[1]);
                const resultDiv = document.createElement('div');
                resultDiv.classList.add('result-container');

                function span(optionId, option) {
                    return `<span class="option ${result.correct_answer === optionId ? 'correct' : (result.selected_answer.split(",")[1] === option ? 'selected' : '')}">${option}</span>`
                }
                resultDiv.innerHTML = ` 
                <div class="question">${result.question}</div>
                <div class="options">
                    ${span('a',result.option1)}
                    ${span('b',result.option2)}
                    ${span('c',result.option3)}
                    ${span('d',result.option4)}
                </div>
                ${!result.is_correct ? `<div class="explanation">${result.explanation}</div>` : ''}`;

                container.appendChild(resultDiv);
            });
        }
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\obesiq\resources\views/admin/quiz-result/index.blade.php ENDPATH**/ ?>