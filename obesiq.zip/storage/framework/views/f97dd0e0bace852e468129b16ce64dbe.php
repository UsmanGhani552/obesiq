<header class="d-flex">
    <button class="btn btn-primary d-sm-block d-md-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
        <i class="bi bi-list"></i>
    </button>
    <form action="">
        <div class="input-group">
            <button class="btn">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <g clip-path="url(#clip0_423_566)">
                      <path d="M19.7552 18.5773L14.781 13.6032C16.1365 11.9453 16.803 9.8299 16.6425 7.69445C16.4821 5.55901 15.507 3.56693 13.919 2.13025C12.331 0.693577 10.2515 -0.0777715 8.1107 -0.024245C5.96991 0.0292815 3.93158 0.903588 2.41734 2.41783C0.903099 3.93207 0.0287933 5.97039 -0.0247333 8.11119C-0.0782598 10.252 0.693089 12.3314 2.12976 13.9195C3.56644 15.5075 5.55852 16.4826 7.69396 16.643C9.82941 16.8035 11.9448 16.137 13.6027 14.7815L18.5768 19.7557C18.734 19.9075 18.9445 19.9914 19.163 19.9895C19.3815 19.9876 19.5905 19.9 19.745 19.7455C19.8995 19.591 19.9872 19.382 19.9891 19.1635C19.991 18.945 19.907 18.7345 19.7552 18.5773ZM8.33266 14.9998C7.01412 14.9998 5.72519 14.6088 4.62886 13.8763C3.53253 13.1437 2.67805 12.1025 2.17347 10.8844C1.66888 9.6662 1.53686 8.32576 1.79409 7.03255C2.05133 5.73934 2.68627 4.55146 3.61862 3.61911C4.55097 2.68676 5.73885 2.05182 7.03206 1.79458C8.32527 1.53735 9.66571 1.66937 10.8839 2.17395C12.1021 2.67854 13.1433 3.53302 13.8758 4.62935C14.6083 5.72568 14.9993 7.01461 14.9993 8.33315C14.9973 10.1007 14.2943 11.7952 13.0445 13.045C11.7947 14.2948 10.1002 14.9978 8.33266 14.9998Z" fill="#1581B1"/>
                    </g>
                    <defs>
                      <clipPath id="clip0_423_566">
                        <rect width="20" height="20" fill="white"/>
                      </clipPath>
                    </defs>
                  </svg>
            </button>
            <input type="text" class="form-control">
        </div>
    </form>
    <div class="profileBox ms-auto">
        <div class="dropdown">
            <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?php echo e(asset('assets/img/avatar.png')); ?>" alt="">
              <h4>Sela Web</h4>
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
        </div>
        
        
    </div>
  </header><?php /**PATH D:\Downloads\laragon\www\obesiq\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>