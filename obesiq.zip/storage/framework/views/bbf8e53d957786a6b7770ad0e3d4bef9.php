
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="startQuizDiv">
    <div class="container-fluid">
        <div class="headingSec d-flex">
            <h2>Progress</h2>
            
            <form action="<?php echo e(route('quiz.attempt')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="subject" id="selectedSubject">
                <input type="hidden" name="type" id="selectedType">
                <input type="hidden" name="category" id="selectedCategory">

                <button class="btn" id="startQuizForm" type="submit">Start Quiz</button>
            </form>
        </div>
        <div class="startQuizBox">
            <div class="row">
                <div class="col-lg-3">
                    <h3>Type</h3>
                    <input type="radio" class="btn-check" name="type" id="timed" value="timed" autocomplete="off">
                    <label class="btn btn-secondary" for="timed">Timed</label>
                    <input type="radio" class="btn-check" name="type" id="un-timed" value="un-timed" autocomplete="off">
                    <label class="btn btn-secondary" for="un-timed">Un-Timed</label>
                </div>
                <div class="col-lg-3">
                    <h3>Category</h3>
                    <input type="radio" class="btn-check" name="category" id="unanswered" value="unanswered" autocomplete="off">
                    <label class="btn btn-secondary" for="unanswered">Unanswered</label>
                    <input type="radio" class="btn-check" name="category" id="answered" value="answered" autocomplete="off">
                    <label class="btn btn-secondary" for="answered">Answered</label>
                    <input type="radio" class="btn-check" name="category" id="marked" value="marked" autocomplete="off">
                    <label class="btn btn-secondary" for="marked">Marked</label>
                </div>
                <div class="col-lg-6">
                    <h3>Subjects</h3>
                    <div class="d-flex">
                        <?php $__currentLoopData = $subjects->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="column">
                                <?php $__currentLoopData = $subjectChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="radio" class="btn-check" name="subject" id="subject-<?php echo e($subject->id); ?>" value="<?php echo e($subject->id); ?>" autocomplete="off">
                                    <label class="btn btn-secondary" for="subject-<?php echo e($subject->id); ?>"><?php echo e($subject->title); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $('#startQuizForm').on('click' , function() {
        // e.preventDefault();
        var type = $('input[name="type"]:checked').val();
        var category = $('input[name="category"]:checked').val();
        var subject = $('input[name="subject"]:checked').val();
        console.log(subject,type,category);

        if (type && category && subject) {
            $('#selectedType').val(type);
            $('#selectedCategory').val(category);
            $('#selectedSubject').val(subject);
        } else {
            event.preventDefault();
            alert('Please select a type, category, and subject.');
        }
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\obesiq\resources\views/quiz/index.blade.php ENDPATH**/ ?>