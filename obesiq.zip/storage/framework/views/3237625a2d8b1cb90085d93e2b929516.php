
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .option-btn.selected {
        background-color: #596268 !important;
    }

    .option-btn.disabled {
        background-color: #f8f9fa;
        color: #6c757d;
        border: 1px solid #dee2e6;
        pointer-events: none;
    }

    .hidden {
        visibility: hidden
    }

</style>
<div class="quizDiv">
    <div class="container-fluid">
        <div class="headingSec d-flex">
            <h2 id="quiz-title">Quiz</h2>
            <div class="btn-group">
                <h5 id="timer">05:25</h5>
                <button class="btn">Save & Exit</button>
            </div>
        </div>
        <div class="quizBox">
            <div class="question">
                <div class="questionBox">
                    <h6 id="question-number">Question No 1</h6>
                    <p id="question-text">Loading question...</p>
                </div>
                
                <div class="flag">
                    <button class="btn">Flag Question</button>
                </div>
            </div>
            <div class="options"></div>
            <div class="navigation">
                <button class="previous btn">PREVIOUS</button>
                <button class="next btn">NEXT</button>
                <button class="btn btn-primary" id="submit-quiz">Submit Quiz</button>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        // Set the duration (in seconds) for the countdown
        var duration = 1 * 60; // 5 minutes

        // Update the timer display every second
        var timerInterval = setInterval(function() {
            var minutes = Math.floor(duration / 60);
            var seconds = duration % 60;

            // Format the time as MM:SS
            var formattedTime =
                (minutes < 10 ? '0' : '') + minutes + ":" +
                (seconds < 10 ? '0' : '') + seconds;

            $('#timer').text(formattedTime);

            // Decrement the duration
            duration--;

            // Check if the timer has reached zero
            if (duration < 0) {
                clearInterval(timerInterval);
                $('#timer').text("Time's up!");
                submitQuiz();
            }
        }, 1000);
        
        const subjectId = 1; // Replace with dynamic subject ID
        let currentQuestion = 0;
        let answers = {};
        let questions = []; // Define the questions variable here

        function loadQuiz() {
            $.ajax({
                url: `/quiz/${subjectId}`
                , method: 'GET'
                , success: function(data) {
                    if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
                        questions = data.questions; // Assign fetched questions to the global variable
                        loadQuestion(currentQuestion);
                    } else {
                        console.error('No questions found for the quiz.');
                    }
                }
                , error: function(err) {
                    console.error('Error fetching quiz data:', err);
                }
            });
        }

        function loadQuestion(index) {
            if (questions.length > 0 && index < questions.length) {
                const question = questions[index];
                $('#question-number').text('Question No ' + (index + 1));
                $('#question-text').text(questions[index].question);
                $('.options').empty();

                // Use the separate option fields
                const options = [
                    question.option1
                    , question.option2
                    , question.option3
                    , question.option4
                ];
                // Default to an empty array if options is undefined
                $.each(options, function(i, option) {
                    $('.options').append(
                        `<button class="nav-link pill option-btn" id="${changeToAlpha(i)}" data-question-id="${questions[index].id}" data-option="${option}">${option}</button>`
                    );
                });
            } else {
                console.error('Question index is out of bounds or questions array is empty.');
            }
        }

        function changeToAlpha(i) {
            switch (i) {
                case 0:
                    return 'a';
                case 1:
                    return 'b';
                case 2:
                    return 'c';
                case 3:
                    return 'd';
            }
        }

        $(document).on('click', '.option-btn', function() {

            const questionId = $(this).data('question-id');
            const selectedOption = $(this).data('option');
            var elementId = $(this).attr('id');

            // Remove selected class from other buttons for the same question
            $(`.option-btn[data-question-id="${questionId}"]`).removeClass('selected');

            // Add selected class to the clicked button
            $(this).addClass('selected');
            answers[questionId] = elementId + ',' + selectedOption;
        });

        $('.next').click(function() {
            $('.previous').removeClass('hidden')
            if (currentQuestion >= questions.length - 2) {
                $(this).addClass('hidden')
            }
            currentQuestion++;
            loadQuestion(currentQuestion);
        });

        $('.previous').click(function() {
            $('.next').removeClass('hidden')
            if (!(currentQuestion > 1)) {
                $(this).addClass('hidden')
            }
            if (currentQuestion > 0) {
                currentQuestion--;
                loadQuestion(currentQuestion);
            }
        });

        // Function to submit the quiz
        function submitQuiz() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#answers').val(JSON.stringify(answers));
            console.log(answers);

            $.ajax({
                url: `/quiz/submit`
                , method: 'POST'
                , data: {
                    subject_id: subjectId
                    , answers: answers
                , }
                , success: function(data) {
                    console.log(data);
                    sessionStorage.setItem('quizResults', JSON.stringify(data.results));
                    if (data.status_code == 200) {
                        window.location.href = '/quiz-results';
                    }
                }
                , error: function(err) {
                    console.error('Error posting:', err);
                }
            });
        }

        // Also submit the quiz manually when the submit button is clicked
        $('#submit-quiz').click(function(e) {
            e.preventDefault();
            submitQuiz();
        });
        loadQuiz(); // Initialize the quiz on page load
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\obesiq\resources\views/admin/quiz-attempt/index.blade.php ENDPATH**/ ?>